
function onEnterTrigger(context, trigger, collider)
	Yield(trigger, 1.0)
	EndLevel(context)
end


function onExitTrigger(context, trigger, collider)
end