function onEnterTrigger(context, trigger, collider)
	Heal(collider, 20);
end